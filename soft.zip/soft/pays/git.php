 <?php

require 'conn.php';

if (isset($_POST['update'])) {

$state= 'paid';

$sql = "UPDATE payment SET state = '$state' WHERE pass = '{$_COOKIE['pass']}' AND product = 'git' ";

$result = mysqli_query($conn, $sql);

if ($result) {
header('location:  http://localhost/learn/journey.php');
}else {
    echo "Error";
}

}

if ($_GET['reference'] == null) {
header('location: http://localhost/learn/journey.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Continue....</title>

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:700" rel="stylesheet">

    <!-- Font Awesome Icon -->
    <link type="text/css" rel="stylesheet" href="http://localhost/learn/file/css/font-awesome.min.css" />

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="http://localhost/learn/file/css/style.css" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>

<body>

    <div id="notfound">
        <div class="notfound">
            <div class="notfound-bg">
                <div></div>
                <div></div>
                <div></div>
            </div>
            <h1 style="font-size: 25px; ">Thank you for your purchase !</h1>
            <h2>Click here to continue</h2>
            <form action="git.php" method="post">
           <button name="update" type="submit" style="border:none;">Continue</button>
       </form>
            <div class="notfound-social">
                <a href="https://web.facebook.com/Softnotch-Intergrated-2131664426882628/"><i class="fa fa-facebook"></i></a>
                <a href="https://www.instagram.com/softnotch/"><i class="fa fa-instagram"></i></a>
                       </div>
    </div>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
