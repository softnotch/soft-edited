<?php

//$conn = mysqli_connect('localhost', 'web', 'Opensesame123.', 'softlearn');
$conn = mysqli_connect('localhost', 'root', '', 'wakocoding');

?>
