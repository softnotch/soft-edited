<?php
   include("conn.php");
   session_start();
   
   if(isset($_POST['login'])) {
      // email and secret sent from form 
      
      $myemail = mysqli_real_escape_string($conn,$_POST['email']);
      $mypass = mysqli_real_escape_string($conn,$_POST['secret']); 
      
      $sql = "SELECT * FROM tutors WHERE email = '$myemail' and secret = '$mypass' ";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

      
      $count = mysqli_num_rows($result);
      
      // If result matched $myemail and $mypass, table row must be 1 row
        
      if($count == 1) {
         header("location: home.php");
         setcookie("email", $_POST['email'], time() +(1*365*24*60*60));
         setcookie("secret", $_POST['secret'], time() +(1*365*24*60*60));
      }else {
         $error = "Your Email Address or Password is invalid";
      }
   }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Soft Learn | Login</title>
    <meta charset="UTF-8">
    <meta name="description" content="WebUni Education Template">
    <meta name="keywords" content="webuni, education, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->   
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!---Font Awesome--->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" type="text/css">


    <link rel="stylesheet" href="http://localhost/learn/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/owl.carousel.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/style.css"/>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<div >
        <!-- signup section -->
    <section class="signup-section spad" id="register">
        <div class="signup-bg set-bg" data-setbg="img/signup-bg.jpg"></div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="signup-warp">
                        <div class="section-title text-white text-left">
                            <h2 style="font-family: 'Nunito', sans-serif; width: 100%;">Login to your account</h2>
                            <p style="font-family: 'Nunito', sans-serif; ">Join Wakocoding Today to add to our courses to day.</p>
                        </div>
                        <!-- signup form -->
                        <form class="signup-form" action="login.php" method="post">
                            <p style="color: red;"><?php echo $error; ?></p>
                            <input type="email" placeholder="Your E-mail" name="email">
                            <input type="password" placeholder="Secret Key" name="secret">

                            <button class="site-btn" style="background: black;" name="login" type="submit">Login</button>
                        </form>
                        <br>
                               <a href="http://localhost/learn/#register" style="color: white; font-family: 'Nunito', sans-serif; width: 100%;">Not have an account ? Register</a>
                               <br>
                               <a href="#"  style="color: white; font-family: 'Nunito', sans-serif; width: 100%;">Student Login</a>
                    </div>
                </div>  
                   </div>
</div>
            </div>
        </div>

    </section>
    <!-- signup section end -->


</div>
</body>
</html>