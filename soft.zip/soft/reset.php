<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
   
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="img/WAKKO22.png" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!---Font Awesome--->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" type="text/css">


    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    <link rel="stylesheet" href="css/owl.carousel.css"/>
    <style>
    body{
    background-image:linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),url(img/programming.jpg);
    height: 100vh;
    background-size: cover;
    background-position: center; 
} 
.login-page{
    width: 360px;
    padding: 10% 0 0;
    margin: auto;
}

.form{
    position: relative;
    z-index:0;
    background:#91d8f7;
    max-width: 360px;
    margin: 0 auto 100px;
    padding: 45px;
    text-align: center;
}

.form input{ 
    font-family: 'Roboto', sans-serif;
    outline: 1;
    background: #f2f2f2;
    width:100%;
    border: 0;
    margin: 0 0 15px;
    padding: 15px;
    box-sizing: border-box;
    font-size:14px;
}

/* .form button{
    font-family: 'Roboto', sans-serif;
    text-transform: uppercase;
    outline: 0;
    background:#4caf50;
    width: 100%;
    border:0;
    padding:15px;
    color:#fff;
    font-size: 14px;
    cursor:pointer;
} */

/* .form button:hover,.form button:active{
    background: #43a047;
} */

form .message{
    margin: 15px 0 0;
    color:#777;
    font-size:12px;
}

form .message a{
    text-decoration:none !important;
    font-weight: 900;
    font-size: larger;
    
}
form .register-form{
    display: none;
}

p{
    color:#777;
    font-weight: 900;
    font-size: larger;
    
}

.emma{
    position: relative;
    top: -42px;
    right: -165px;
    font-weight: 900;
    font-size: x-large;
    color: #777 !important;
    text-decoration: none !important;
    text-decoration-color: rgba(0,0,0,0.6)!important;
}

.emma:hover{ color:#777 !important}


    </style>
</head>
<body>

    <!-- .login-page>.form>.register-form>input[type][placeholder][id]*3+button:s -->
   <section class="container">
    <div class="login-page">
        <div class="form jumbotron">


            <form action="" class="login-form ">
                    <a class="emma" href="index.php"><span>&times</span></a>
                
                <input class="form-control" type="text" placeholder="New password" id="password" required>
                <input type="password" class="form-control" placeholder="Confirm password" id="confirm_password"required>
                <button class="btn btn-outline-info" type="submit" id="upd">update</button>
            </form>
        </div>
    </div>
</section>
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/index.js"></script>
        
    
</body>
</html>