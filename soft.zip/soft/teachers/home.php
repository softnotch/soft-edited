<?php
require 'teacher_fetch.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Teachers | Home</title>
    <meta charset="UTF-8">
    <meta name="description" content="WebUni Education Template">
    <meta name="keywords" content="webuni, education, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->   
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!---Font Awesome--->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" type="text/css">


    <link rel="stylesheet" href="http://localhost/learn/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/owl.carousel.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/style.css"/>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
    <style type="text/css">

        input[type='text']{
            width: 18rem;
            border:none;
            -webkit-box-shadow: 3px 3px 42px -12px rgba(0,0,0,0.75);
           -moz-box-shadow: 3px 3px 42px -12px rgba(0,0,0,0.75);
           box-shadow: 3px 3px 42px -12px rgba(0,0,0,0.75);
           margin-top: 1rem;
           font-family: 'Quicksand', sans-serif;
           font-size: 15px;
           font-weight:500;
        }
        .form {
     width: 400px;
}
 .file-upload-wrapper {
     position: relative;
     width: 100%;
     height: 60px;
}
 .file-upload-wrapper:after {
     content: attr(data-text);
     font-size: 18px;
     position: absolute;
     top: 0;
     left: 0;
     background: #fff;
     padding: 10px 15px;
     display: block;
     width: calc(100% - 40px);
     pointer-events: none;
     z-index: 20;
     height: 40px;
     line-height: 40px;
     color: #999;
     border-radius: 5px 10px 10px 5px;
     font-weight: 300;
}
 .file-upload-wrapper:before {
     content: 'Upload';
     position: absolute;
     top: 0;
     right: 0;
     display: inline-block;
     height: 60px;
     background: #4daf7c;
     color: #fff;
     font-weight: 700;
     z-index: 25;
     font-size: 16px;
     line-height: 60px;
     padding: 0 15px;
     text-transform: uppercase;
     pointer-events: none;
     border-radius: 0 5px 5px 0;
}
 .file-upload-wrapper:hover:before {
     background: #3d8c63;
}
 .file-upload-wrapper input {
     opacity: 0;
     position: absolute;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     z-index: 99;
     height: 40px;
     margin: 0;
     padding: 0;
     display: block;
     cursor: pointer;
     width: 100%;
}

    </style>
       <?php foreach($posts as $post): ?>
  <header class="header-section" style="position: fixed; top:0rem; width: 100%; z-index: 10000; background: white; height: 26%;">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="site-logo">
                        <h2 style="color: black; font-family: 'Nunito', sans-serif;">Soft Learn</h2>
                    </div>
                    <div class="nav-switch">
                        <i class="fa fa-bars"></i>
                    </div>
                </div>
                <div class="col-lg-9 col-md-9">
                    <a href="#" class="site-btn header-btn"><?php echo $post['name']; ?></a>
                    <nav class="main-menu" style="display: block;">
                        <ul>
                            <li><a href="index.php" style="color: black;">Home</a></li>
                            <li><a href="http://localhost/learn/courses.html" style="color: black;">Tutorials/Courses</a></li>
                            <li><a href="account.php" style="color: black;">Account</a></li>
                             <li><a href="contact.php" style="color: black;">Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    </header>
    <!----Mains---->
<div class="container">
    <div class="row" style="padding-top: 12.4em;">
        <div class="col-lg-6 col-md-6" id="inputs" style="margin-left: 6rem;">
<form>
                    <h4 style="margin-left: 4rem;">Learning Path</h4>
           <textarea >
               
           </textarea>
</form>
    </div>

    <div class="col-lg-4 col-md-6">
        <br>
        <br>
    <form class="form">
        <h4 style="font-family: 'Nunito', sans-serif; margin-left: 6rem;">Upload video file</h4>
        <br>
    <div class="file-upload-wrapper" data-text="Select your file!">
      <input name="file-upload-field" type="file" class="file-upload-field" value="" style="border: 1px solid darkgray;">
    </div>
  </form>
    </div>
    </div>
</div>
<!---Scripts--->
    <script src="http://localhost/learn/js/jquery-3.2.1.min.js"></script>
    <script src="http://localhost/learn/js/bootstrap.min.js"></script>
    <script src="http://localhost/learn/js/mixitup.min.js"></script>
    <script src="http://localhost/learn/js/circle-progress.min.js"></script>
    <script src="http://localhost/learn/js/owl.carousel.min.js"></script>
    <script src="http://localhost/learn/js/main.js"></script>
</body>
</html>