<?php
require 'conn.php';

$state  = 'unpaid';

$sql = "UPDATE users SET state = '$state' WHERE pass  = '{$_COOKIE['pass']}' ";

$result = mysqli_query($conn, $sql);

if ($result) {
header('location:pay.php');
}else{
    header('location:login.php');
}

?>
