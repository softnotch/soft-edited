<?php
    session_start(); 
    session_unset();
    session_destroy();

    header("location: login.php");
    //cookie kill
    setcookie("user", "");
    setcookie("pass", "");
    exit(0);
?>