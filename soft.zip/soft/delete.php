<?php require 'fetch.php'; ?>
<?php foreach($posts as $post): ?>

<?php
require 'conn.php';
$idp = $post['id'];
echo $idp;

// sql to delete a record
$sql = "DELETE  FROM users WHERE id='$idp' ";



if ($conn->query($sql) === TRUE) {
  header('location: login.php');
    session_start(); 
    session_unset();
    session_destroy();
    setcookie("user", "");
    setcookie("pass", "");
    exit(0);
} else {
    echo "<script type='text/javascript'>alert(An internal error occured);</script>";
}

$conn->close();
?>
<?php endforeach; ?>