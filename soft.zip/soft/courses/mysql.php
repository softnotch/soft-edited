<?php
include 'fetch.php';

if ($_GET['code'] == null) {
header('location:http:///localhost/learn/journey.php');
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Database Manipulation | Home</title>
    <meta charset="UTF-8">
    <meta name="description" content="WebUni Education Template">
    <meta name="keywords" content="webuni, education, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->   
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!---Font Awesome--->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" type="text/css">


    <link rel="stylesheet" href="http://localhost/learn/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="http://localhost/learncss/owl.carousel.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/style.css"/>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
    <style type="text/css">
        body{
            overflow-y: auto;
        }
#dialog-window {
  height: 400px;
  background: #e55039;
  color: white;
  font-family: 'Nunito', sans-serif;
  border-radius: 10px;
}

#scrollable-content {
  height: 400px;
  overflow: auto;
}
ul li{
    list-style: none;
    text-decoration: none;
    margin-top: 1.5rem;
}


    </style>

    <!-- Header section -->
    <?php foreach($posts as $post): ?>
    <header class="header-section" style="position: fixed; top:0rem; width: 100%; z-index: 10000; background: white; height: 26%;">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="site-logo">
                        <h2 style="color: black; font-family: 'Nunito', sans-serif;">Soft Learn</h2>
                    </div>
                    <div class="nav-switch">
                        <i class="fa fa-bars"></i>
                    </div>
                </div>
                <div class="col-lg-9 col-md-9">
                    <a href="login.php" class="site-btn header-btn"><?php echo $post['user']; ?></a>
                    <nav class="main-menu" style="display: block;">
                        <ul>
                            <li><a href="http://localhost/learn" style="color: black;">Home</a></li>
                            <li><a href="http://localhost/learn/journey.php" style="color: black;">Tutorials/Courses</a></li>
                            <li><a href="http://localhost/learn/account.php" style="color: black;">Account</a></li>
                             <li><a href="contact.html" style="color: black;">Contact</a></li>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="title" style="background: #d63031; margin-top: 1.8rem;">
<div style="padding: 1rem 1rem 1rem 1rem; ">
    <h5 style="font-family: 'Nunito', sans-serif; color: white;">UI AND UX Design</h5>
</div>
</div>
</header>
          <?php endforeach; ?>
    <!-- Header section end -->



    <!----Video Tutorial ---->
    <div style="padding-top: 12.4em;">
<div class="embed-responsive embed-responsive-21by9">

<iframe src="https://drive.google.com/file/d/1dnsJKl5ghwvK6vRgb4RmCavbV2zMyg9c/preview" width="640" height="520"></iframe>
</div>
<!----End--->

<!----Comments ---->
<br>
<br>

<div class="container">
    <div class="row">
<div class="col-sm-10">
<!---List---->
<div id="dialog-window"  style="margin-top: -1.5rem;">
<div id="scrollable-content">
<div style="padding-top: 1.5rem; margin-left: 1rem;">
<ul>
      <li>Introduction to mysql<span style="background:  #e55039; opacity:0.8; margin-left: 2rem; color: white; padding: 0.4rem 0.4rem 0.4rem 0.4rem; box-shadow: 0 4px 4px 3px rgba(0, 0, 0, 0.1); border-radius:12px ; ">1:00</span> </li>
      <li>Types of database<span style="background:  #e55039; opacity:0.8; margin-left: 2rem; color: white; padding: 0.4rem 0.4rem 0.4rem 0.4rem; box-shadow: 0 4px 4px 3px rgba(0, 0, 0, 0.1); border-radius:12px ; ">2:00</span> </li>
      <li>Connect php and mysql<span style="background:  #e55039; opacity:0.8; margin-left: 2rem; color: white; padding: 0.4rem 0.4rem 0.4rem 0.4rem; box-shadow: 0 4px 4px 3px rgba(0, 0, 0, 0.1); border-radius:12px ; ">3:00</span> </li>
       <li>Alter database with php & mysql <span style="background:  #e55039; opacity:0.8; margin-left: 2rem; color: white; padding: 0.4rem 0.4rem 0.4rem 0.4rem; box-shadow: 0 4px 4px 3px rgba(0, 0, 0, 0.1); border-radius:12px ; ">4:00</span> </li>
      <li>Data types<span style="background:  #e55039; opacity:0.8; margin-left: 2rem; color: white; padding: 0.4rem 0.4rem 0.4rem 0.4rem; box-shadow: 0 4px 4px 3px rgba(0, 0, 0, 0.1); border-radius:12px ; ">5:00</span> </li>
</ul>
</div>
</div>
</div>  
<!---End--->
</div>

<div class="col-sm-10" style="margin-top: 2rem;">
    <div id="disqus_thread"></div>
</div>
    </div>
</div>





<!----end--->
    <!--====== Javascripts & Jquery ======-->
    <script>
(function() { // DON'T EDIT BELOW THIS LINE
var d = document, s = d.createElement('script');
s.src = 'https://http-localhost-learn.disqus.com/embed.js';
s.setAttribute('data-timestamp', +new Date());
(d.head || d.body).appendChild(s);
})();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
                            
    <script src="http://localhost/learn/js/jquery-3.2.1.min.js"></script>
    <script src="http://localhost/learn/js/bootstrap.min.js"></script>
    <script src="http://localhost/learn/js/mixitup.min.js"></script>
    <script src="http://localhost/learn/js/circle-progress.min.js"></script>
    <script src="http://localhost/learn/js/owl.carousel.min.js"></script>
    <script src="http://localhost/learn/js/main.js"></script>
</body>
</html>