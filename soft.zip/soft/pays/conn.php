<?php

// $conn = mysqli_connect('localhost', 'root', '123456', 'softlearn');
$conn = mysqli_connect('localhost', 'root', '', 'wakocoding');

?>