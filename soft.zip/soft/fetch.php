<?php
require  'conn.php';

$query  = "SELECT id, user, email FROM users WHERE pass = '{$_COOKIE['pass']}' ";

$result   = mysqli_query($conn, $query);

$posts =  mysqli_fetch_all($result, MYSQLI_ASSOC);

mysqli_free_result($result);

mysqli_close($conn);


?>
