<?php

include 'conn.php';

 if (isset($_POST['save'])) {

    $user = $_POST['user'];
    $email = $_POST['email'];

 $query = mysqli_query($conn, "UPDATE users SET  user= '$user', email= '$email' WHERE pass = '{$_COOKIE['pass']}'  " );

if ($query) {
header('location: account.php');
    }else {
        echo "<script type='text/javascript'>alert('An internal error occured');</script>";
}

}   
        ?>